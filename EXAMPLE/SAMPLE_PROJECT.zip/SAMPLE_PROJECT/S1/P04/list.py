

import os
curdir = os.getcwd()   


listFiles = os.listdir(curdir)
print("listFiles :\n", listFiles)
listFiles.sort()
print("listFiles Sorted \n:", listFiles)
print("..........")

listPics = []
print("listPics:", listPics)
emptyPics = []
print("emptyPics:", listPics)
validShot = 1
print("VALIDSHOT :", validShot)
print("..........")

for file in listFiles:
	if file == ".bounds":
		print(file, "exists.")
	elif file == "list.py":
		print(file, "exists.")
	else:
		listPics.append(file)
print("listPics :", listPics)
print("..........")

def verifyPics():
	for spic in listPics:
		size = os.stat(spic).st_size
		if size == 0:
			print("ZERO :", repr(size).rjust(10), spic.ljust(10))
			emptyPics.append(spic)
			validShot = 0
		else:
			print("OK   :", repr(size).rjust(10), spic.ljust(10))
	print("VALIDSHOT :", validShot)
	return validShot;
validShot = verifyPics()

print("..........")
print("VALIDSHOT :", validShot)
print("EMPTYPICS :", emptyPics)
print("")


# ----------------------------------------
### Is shot valid ?
def isShotValid():
	# print("VALIDSHOT :", validShot)
	if validShot == 0:
		print("# ----------------------------------------")
		print("WARNING :", curdir)
		print("          has invalid or missing files")
		print("# ----------------------------------------")
	else:
		print("# ----------------------------------------")
		print("OK : ", curdir)
		print("# ----------------------------------------")
isShotValid()





